Preinstall:

Python download: https://www.python.org/downloads/ 
Download version: 3.11.4

While downloading, check mark Add to Environment variable 

Then run the below commands:

pip install scikit-learn
pip install tensorflow
pip install pandas
pip install numpy
pip install flask
pip install yfinance
pip install feedparser
pip install scipy
pip install plotly

To start the website:
streamlit run app.py