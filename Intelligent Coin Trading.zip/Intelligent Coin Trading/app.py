import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import yfinance as yf
from datetime import datetime as datetime
from datetime import timedelta
import streamlit as st
import plotly.figure_factory as ff
from sklearn.preprocessing import MinMaxScaler
from keras.layers import Dense, Dropout, LSTM
from keras.models import Sequential
import math
from sklearn.metrics import mean_squared_error, mean_absolute_error
import feedparser

st.title("Intelligent Coin Platform")

user_input = st.text_input('Enter Crypto Stocks', 'BTC-USD') 

if user_input:
    try:
        df = yf.download(user_input, period="1y", progress=False)  
        st.subheader(f"Cryptocurrency Data for {user_input}")
        st.write(df)

        st.write(df.describe())

        # START: Visualization Charts Code  
        # Display histograms using df.hist
        st.subheader("Histograms for " + user_input + " data")
        fig, axes = plt.subplots(nrows=1, ncols=len(df.columns), figsize=(15, 5))
        df.hist(ax=axes)

        # Display the histograms using st.pyplot
        st.pyplot(fig)

        # Display subplots using df.plot
        st.subheader("Subplots for " + user_input + " data")
        fig, axes = plt.subplots(subplot_kw={'sharex': False}, nrows=3, ncols=2, figsize=(10, 8))
        df.plot(subplots=True, layout=(3, 2), ax=axes)

        # Display the subplots using st.pyplot
        st.pyplot(fig)

        #Visualizations
        st.subheader('Closing Price vs Time Chart')
        fig=plt.figure(figsize=(12,6))
        plt.plot(df.Close)
        st.pyplot(fig)

        st.subheader('Closing Price vs Time Chart with 30MA and 60MA')
        ma100 = df.Close.rolling(30).mean()
        ma200 = df.Close.rolling(60).mean()
        fig=plt.figure(figsize=(12,6))
        plt.plot(ma100)
        plt.plot(ma200)
        plt.plot(df.Close)
        st.pyplot(fig)

        correlations = df.corr()

        # Display the correlated cryptocurrencies
        st.subheader("Correlation Matrix")
        st.write(correlations)
        # END: Visualization Charts Code

        #START: Model training 
        
        st.header("Crypto Currency Prediction")

        st.subheader("Train the model")
        look_back = 30  # Number of previous days to use for prediction

        model = Sequential()

        data  = df.drop(['Open', 'High', 'Low', 'Volume'], axis=1)
        scaler = MinMaxScaler(feature_range=(0, 1))

        # LSTM data preparation
        train_size = int(len(data) * 0.6)  # 80% of data for training, 20% for testing

        train_data = data.iloc[:train_size]['Close'].values
        test_data = data.iloc[train_size:]['Close'].values

        def create_dataset(dataset, look_back):
            data_X, data_y = [], []
            for i in range(len(dataset) - look_back):
                data_X.append(dataset[i:i + look_back])
                data_y.append(dataset[i + look_back])
            return np.array(data_X), np.array(data_y)

        train_data = scaler.fit_transform(train_data.reshape(-1, 1))
        test_data = scaler.transform(test_data.reshape(-1, 1))

        train_X, train_y = create_dataset(train_data, look_back)
        train_X = np.reshape(train_X, (train_X.shape[0], train_X.shape[1], 1))

        test_X, test_y = create_dataset(test_data, look_back)
        test_X = np.reshape(test_X, (test_X.shape[0], test_X.shape[1], 1))

        if st.button("Train Model"):
            model.add(LSTM(10,input_shape=( train_X.shape[1], train_X.shape[2]),activation="relu"))
            model.add(Dense(1))
            model.compile(loss="mean_squared_error",optimizer="adam")

            history = model.fit(train_X,train_y,validation_data=(test_X, test_y),epochs=100,batch_size=32,verbose=1)
            train_predict=model.predict(train_X)
            test_predict=model.predict(test_X)  

            train_predict = scaler.inverse_transform(train_predict)
            test_predict = scaler.inverse_transform(test_predict)
            original_ytrain = scaler.inverse_transform(train_y.reshape(-1,1)) 
            original_ytest = scaler.inverse_transform(test_y.reshape(-1,1)) 

            st.title("Loss Curve")

            loss = history.history['loss']
            val_loss = history.history['val_loss']

            epochs = range(len(loss))

            # Plotting using Matplotlib
            fig, ax = plt.subplots()
            ax.plot(epochs, loss, 'r', label='Training loss')
            ax.plot(epochs, val_loss, 'b', label='Validation loss')
            ax.set_title('Training and validation loss')
            ax.legend(loc='best')

            # Display the plot in Streamlit
            st.pyplot(fig)

            st.write("Train data RMSE: ", math.sqrt(mean_squared_error(original_ytrain,train_predict)))
            st.write("Train data MSE: ", mean_squared_error(original_ytrain,train_predict))
            st.write("Train data MAE: ", mean_absolute_error(original_ytrain,train_predict))
            st.write("-------------------------------------------------------------------------------------")
            st.write("Test data RMSE: ", math.sqrt(mean_squared_error(original_ytest,test_predict)))
            st.write("Test data MSE: ", mean_squared_error(original_ytest,test_predict))
            st.write("Test data MAE: ", mean_absolute_error(original_ytest,test_predict))

        #END: Model training

        st.subheader("Predict the future!!")

        data_df = df.reset_index()
        data_df['Date'] = data_df['Date'].dt.date

        # Display the available date range
        start_date = st.date_input("Select Start Date:", min_value=df.index.min(), max_value=df.index.max() + pd.Timedelta(days=1))
        forecast_days = st.slider("Select Forecast Days:", 1, 30, 7)

        if st.button("Predict"):
            start_date_index = data_df[data_df['Date'] == (start_date - pd.Timedelta(days=1))]['Close'].index[0]
            initial_threshold = data_df.loc[start_date_index, 'Close']

            selected_data = data_df[data_df['Date'] < start_date]
            future_dates = [start_date + timedelta(days=i) for i in range(1, forecast_days + 1)]
            future_input_data = selected_data.tail(look_back)['Close'].values
            future_input_data = scaler.transform(future_input_data.reshape(-1, 1))
            
            future_input_data = np.array(future_input_data)
            future_input_data = np.reshape(future_input_data, (future_input_data.shape[0], future_input_data.shape[1], 1))
           
            predicted_prices = []
            predicted_labels = []

            predicted_prices = []
            for _ in range(forecast_days):
                prediction = model.predict(future_input_data)  # Adjust input format if needed
                prediction = scaler.inverse_transform(prediction.reshape(-1, 1))
               
                predicted_prices.append(prediction[0][0])
                predicted_labels.append('Up' if prediction[0][0] > initial_threshold else 'Down')
                initial_threshold = prediction[0][0]
                future_input_data = np.roll(future_input_data, -1)
                future_input_data[-1] = prediction[0][0]

            # Display the predicted prices for future dates
            forecast_df = pd.DataFrame({'Date': future_dates, 'Predicted_Price': predicted_prices, 'Predicted_Label': predicted_labels})
            st.subheader("Predicted Prices for Future Dates")
            st.dataframe(forecast_df)

        
        st.subheader("Prediction for Profit/Loss and High/Low points")

        look_ahead = st.slider("Select Look-Ahead Window (days):", 1, 30, 7)

        # Prepare input data for prediction
        price_data = df['Close'].values.reshape(-1, 1)  # Reshape for MinMaxScaler
        normalized_data = scaler.fit_transform(price_data)  # Normalize the data

        input_sequences = []

        for i in range(len(df) - look_ahead):
            input_sequence = normalized_data[i:i + look_ahead]
            input_sequences.append(input_sequence)

        input_data = np.array(input_sequences)
        input_data = np.reshape(input_data, (input_data.shape[0], input_data.shape[1], 1))

        predictions = model.predict(input_data)
        predictions = scaler.inverse_transform(predictions.reshape(-1,1))
           
        if st.button("Predict High and Low Points"):
            # Make predictions using the LSTM model
            current_price = df['Close'].iloc[-1]

            predicted_high = np.amax(predictions)
            predicted_low = np.amin(predictions)

            predicted_purchase_price = predicted_low
            predicted_sale_price = predicted_high

            # Calculate anticipated profit and loss
            anticipated_profit = predicted_sale_price - predicted_purchase_price
            anticipated_loss = predicted_purchase_price - predicted_sale_price

            st.write(f"Predicted High: {predicted_high}")
            st.write(f"Predicted Low: {predicted_low}")

            st.subheader("Predicted Purchase and Sale")
            st.write(f"Predicted Purchase Price: {predicted_purchase_price}")
            st.write(f"Predicted Sale Price: {predicted_sale_price}")

            st.subheader("Anticipated Profit and Loss")
            st.write(f"Anticipated Profit: {anticipated_profit}")
            st.write(f"Anticipated Loss: {anticipated_loss}")

        st.title("Cryptocurrency News")

        # User input for cryptocurrency selection
        selected_crypto = st.selectbox("Select Cryptocurrency:", ["Bitcoin", "Ethereum", "Cardano", "Ripple", "Litecoin"])

        # Define RSS feed URL for the selected cryptocurrency
        crypto_feeds = {
            "Bitcoin": "https://news.google.com/rss/search?q=Bitcoin&hl=en-US&gl=US&ceid=US:en",
            "Ethereum": "https://news.google.com/rss/search?q=Ethereum&hl=en-US&gl=US&ceid=US:en",
            "Cardano": "https://news.google.com/rss/search?q=Cardano&hl=en-US&gl=US&ceid=US:en",
            "Ripple": "https://news.google.com/rss/search?q=Ripple&hl=en-US&gl=US&ceid=US:en",
            "Litecoin": "https://news.google.com/rss/search?q=Litecoin&hl=en-US&gl=US&ceid=US:en"
        }

        # Fetch and parse the RSS feed
        feed = feedparser.parse(crypto_feeds[selected_crypto])

        # Display top stories
        st.subheader(f"Top Stories about {selected_crypto}")
        for entry in feed.entries:
            st.write(f"**Title:** {entry.title}")
            st.write(f"**Published:** {entry.published}")
            st.write(f"**Link:** {entry.link}")
            st.write("\n")

    except Exception as e:
        st.error("Error fetching data. Please enter a valid cryptocurrency symbol.")

